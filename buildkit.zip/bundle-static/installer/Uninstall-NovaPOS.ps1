﻿<#
.SYNOPSIS
  Uninstall-NovaPOS.ps1 — المرحلة 3/إصلاح: إزالة NovaPOS دون المساس ببيانات المستخدم.
.DESCRIPTION
  يزيل مجلد التثبيت + الاختصار فقط. بيانات المستخدم (%LOCALAPPDATA%\NovaPOS\
  بما فيها nova_pos.db) تبقى سليمة افتراضيًّا.

  **تحصين `-PurgeUserData` (ضمانة ضد حذف بيانات حقيقية بالخطأ):** الحذف الدائم
  مشروط بخمسة بوابات — يجب اجتياز **كلها** قبل أن يُطلب التأكيد، والرفض افتراضي
  في أي حالة غير مطابقة (لا يُحذف شيء):
    1. حارس المسارات المحمية: يُرفض أي مسار فارغ/نسبي/جذر قرص/المجلدات الحساسة
       (%USERPROFILE% · %LOCALAPPDATA% · %APPDATA% · %SystemRoot% · %ProgramFiles%)
       أو مجلد الإنتاج نفسه أو ما تحته — مهما قيل.
    2. سجل تثبيت موثوق: وجود `install-record.json` صالح الـJSON في مجلد التثبيت.
    3. مطابقة المسار حرفيًّا: `dataDirectory` في السجل (بعد تطبيع المسار) يطابق
       `-DataDirectory` المطلوب حذفه — يثبت أن هذا المثبِّت هو من جهَّز هذا المجلد.
    4. ملكية مجلد: مالك مجلد البيانات = المستخدم الحالي أو Administrators.
    5. محتوى مجلد: `nova_pos.db` + علامة إضافية (serverId أو lanClient.json أو Backups\).
  بعد البوابات: تأكيد صريح بكتابة `PURGE` ثم كتابة المسار كاملًا حرفيًّا.
  قاعدة الجدار تُحذف فقط إن سجّل سجل التثبيت أن التثبيت أنشأها فعلًا.
.NOTES
  ممنوع: لمس قاعدة الإنتاج أو أي بيانات خارج -DataDirectory الممرَّر صراحةً ومجازًا.
#>
[CmdletBinding()]
param(
  [string]$InstallDir,
  [string]$DataDirectory,
  [switch]$PurgeUserData
)
$ErrorActionPreference='Stop'

if (-not $InstallDir)    { $InstallDir    = Join-Path $env:ProgramFiles 'NovaPOS' }
if (-not $DataDirectory) { $DataDirectory = Join-Path $env:LOCALAPPDATA 'NovaPOS' }
$InstallDir   = [IO.Path]::GetFullPath($InstallDir)
$DataDirectory= [IO.Path]::GetFullPath($DataDirectory)

function Refuse($gate,$why){
  Write-Host "PURGE REFUSED ($gate): $why"
  Write-Host "  nothing was deleted — user data left untouched at '$DataDirectory'."
  throw "purge refused ($gate): $why"
}

Write-Host "=== NovaPOS Uninstall ($(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) ==="
Write-Host "install dir: $InstallDir"
Write-Host "data dir   : $DataDirectory (protected unless -PurgeUserData passes all gates)"

$running = @(Get-Process -Name 'NovaPOS.App','NovaPOS.Server' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) { throw "NovaPOS is running (pids: $($running.Id -join ', ')) — close it before uninstalling." }

# 1) سجل التثبيت (علم الجدار + مسار الاختصار)
$recordPath = Join-Path $InstallDir 'install-record.json'
$record = $null
if (Test-Path -LiteralPath $recordPath) {
  try { $record = Get-Content -LiteralPath $recordPath -Raw | ConvertFrom-Json } catch { Write-Host "install record unreadable — treating as absent. $_"; $record=$null }
  if ($record) { Write-Host "install record: installed $($record.installedAt) version $($record.productVersion)" }
} else { Write-Host "install record NOT found — proceeding with file removal only." }

# 2) جدار: يُحذف فقط إن هذا التثبيت أنشأه فعلًا
if ($record -and $record.firewallRuleAdded) {
  netsh advfirewall firewall delete rule name="NovaPOS Server" | Out-Null
  Write-Host "firewall rule 'NovaPOS Server' removed (created by this installer)."
} else { Write-Host "firewall: nothing removed (no rule created by this installer)." }

# 3) اختصار
$lnk = if ($record -and $record.shortcut) { $record.shortcut } else { Join-Path ([Environment]::GetFolderPath('Programs')) 'NovaPOS.lnk' }
if (Test-Path -LiteralPath $lnk) { Remove-Item -LiteralPath $lnk -Force; Write-Host "shortcut removed: $lnk" }

# 4) مجلد التثبيت فقط (بلا حذف أي مجلد بيانات)
if (Test-Path -LiteralPath $InstallDir) {
  Remove-Item -LiteralPath $InstallDir -Recurse -Force
  Write-Host "install dir removed: $InstallDir"
} else { Write-Host "install dir already absent: $InstallDir" }

# 5) بيانات المستخدم — محمية افتراضيًا؛ الحذف الدائم خاضع للبوابات الخمس
if ($PurgeUserData) {
  # --- بوابة 1: حارس المسارات المحمية ---
  $lad = [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
  $prodData = if ($lad) { [IO.Path]::GetFullPath((Join-Path $lad 'NovaPOS')).TrimEnd('\') } else { $null }
  # مسارات محمية: مجلد الإنتاج + مجلدات المستخدم الحساسة. لا نضيف جذر القرص (كل
  # مسارات الاختبار المعزولة على نفس القرص، وإلا صار الحارس أعمى ولم تُختبر باقي البوابات).
  $blocked = @($prodData, $env:LOCALAPPDATA, $env:APPDATA, $env:USERPROFILE, $env:SystemRoot, $env:ProgramFiles)
  $blocked = @($blocked | Where-Object { -not [string]::IsNullOrWhiteSpace($_) } | ForEach-Object { [IO.Path]::GetFullPath($_).TrimEnd('\') } | Select-Object -Unique)
  if ([string]::IsNullOrWhiteSpace($DataDirectory)) { Refuse 'protected-path' 'data directory is empty.' }
  foreach($r in $blocked){
    if ([string]::IsNullOrWhiteSpace($r)) { continue }
    $rf = $r.TrimEnd('\')
    if ($DataDirectory.Equals($rf,[StringComparison]::OrdinalIgnoreCase)) { Refuse 'protected-path' "target equals a protected path: $rf" }
    if ($DataDirectory.StartsWith($rf+'\',[StringComparison]::OrdinalIgnoreCase)) { Refuse 'protected-path' "target is inside a protected path: $rf" }
  }
  Write-Host "gate 1 (protected path): OK — target is not a protected/system path."

  # --- بوابة 2: سجل تثبيت موثوق ---
  if (-not $record) { Refuse 'trusted-record' "no valid install-record.json at '$recordPath' — cannot trust that this data dir belongs to NovaPOS." }
  Write-Host "gate 2 (trusted record): OK — install record parsed."

  # --- بوابة 3: مطابقة المسار حرفيًّا للسجل ---
  if ([string]::IsNullOrWhiteSpace($record.dataDirectory)) { Refuse 'path-match' 'install record has no dataDirectory — the installer never provisioned this data dir; refusing to purge.' }
  $recNorm = [IO.Path]::GetFullPath($record.dataDirectory).TrimEnd('\')
  if (-not $recNorm.Equals($DataDirectory,[StringComparison]::OrdinalIgnoreCase)) { Refuse 'path-match' "requested '$DataDirectory' != recorded '$recNorm' — refusing to purge a dir this installer did not provision." }
  Write-Host "gate 3 (path match): OK — target matches the recorded data directory."

  # --- بوابة 4: ملكية المجلد ---
  if (-not (Test-Path -LiteralPath $DataDirectory)) { Refuse 'ownership' "data directory does not exist: '$DataDirectory'." }
  try {
    $owner = (Get-Acl -LiteralPath $DataDirectory).Owner
    $me    = [Security.Principal.WindowsIdentity]::GetCurrent().Name
    $isAdminOwner = $owner -match 'Administrators|S-1-5-32-544'
    if ($owner -ne $me -and -not $isAdminOwner) { Refuse 'ownership' "directory owner '$owner' is neither current user '$me' nor Administrators — refusing." }
    Write-Host "gate 4 (ownership): OK — owner '$owner'."
  } catch { Refuse 'ownership' "could not verify directory ownership: $_" }

  # --- بوابة 5: محتوى مجلد NovaPOS ---
  $dbOk = Test-Path -LiteralPath (Join-Path $DataDirectory 'nova_pos.db')
  $mark = @('serverId','lanClient.json','Backups') | Where-Object { Test-Path -LiteralPath (Join-Path $DataDirectory $_) }
  if (-not $dbOk) { Refuse 'content' 'nova_pos.db not present — not a NovaPOS data dir.' }
  if ($mark.Count -eq 0) { Refuse 'content' 'no NovaPOS marker (serverId / lanClient.json / Backups\) beside the database — refusing to purge a generic folder.' }
  Write-Host "gate 5 (content): OK — nova_pos.db + marker(s): $($mark -join ', ')."

  # --- تأكيد صريح من خطوتين ---
  Write-Host ""
  Write-Host "ALL FIVE GATES PASSED. This will PERMANENTLY delete:"
  Write-Host "  $DataDirectory"
  $a1 = Read-Host "Type PURGE to proceed"
  if ($a1 -ne 'PURGE') { Write-Host "purge cancelled — user data kept."; exit 0 }
  $a2 = Read-Host "Type the full data path exactly to confirm"
  if ($a2.TrimEnd('\') -ne $DataDirectory.TrimEnd('\')) { Write-Host "path mismatch — purge cancelled, user data kept."; exit 0 }
  Remove-Item -LiteralPath $DataDirectory -Recurse -Force
  Write-Host "user data purged: $DataDirectory"
} else {
  $db = Join-Path $DataDirectory 'nova_pos.db'
  Write-Host "user data KEPT: $DataDirectory (db exists=$(Test-Path -LiteralPath $db)) — see BACKUP-RESTORE.md (DS-6) before any manual deletion."
}

Write-Host "UNINSTALL DONE — INS-1/A-8 remain open until clean-device execution."
exit 0
