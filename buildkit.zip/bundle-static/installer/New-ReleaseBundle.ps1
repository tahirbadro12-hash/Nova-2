﻿<#
.SYNOPSIS
  New-ReleaseBundle.ps1 — المرحلة 3/إصلاح: بناء مرشح التوزيع من حزمة أساس + ملفات المرحلة 3.
.DESCRIPTION
  يبني مرشحًا جديدًا (rc-r6) من حزمة الأساس (rc-r5 = rc-r4 + الملفات الخمسة الأصلية)
  + الملفات الخمسة المُصحَّحة (BACKUP-RESTORE.md + installer\). لا يمس حزمة الأساس
  ولا أي حزمة محمية: ينسخ ثم يتحقق بالتجزئة من مطابقة كل ملف غير-مُضاف-جديدًا لبيان
  الأساس، ثم يبني بيان المرشح الجديد بنفس تنسيق الجولات السابقة.
  التحققات المعلنة: added=0 · removed=0 · changed ∈ {0,5} · الملفات المسموح بتغييرها
  هي الخمسة المعروفة فقط — أي تغيير خارجها = فشل صريح (لا إخفاء).
.NOTES
  الصيغة/النطاق: وفق a21-stage3-install-plan.md + خطة الإصلاح a21-stage3-fix-plan.md.
  الممنوع: تعديل src\ أو tests\ أو ProductVersion أو الحزم المحمية.
#>
[CmdletBinding()]
param(
  [string]$SourceBundle,        # حزمة الأساس (rc-r5)
  [string]$SourceManifest,      # بيان حزمة الأساس (r5-manifest.txt)
  [string]$OutDir,              # مجلد المرشح الجديد (rc-r6)
  [string]$OutManifestName,     # اسم بيان المرشح الجديد (r6-manifest.txt)
  [string]$ManifestHeader,      # ترويسة البيان الجديدة
  [string]$BaseNote,            # سطر الأساس في الترويسة
  [string]$InstallerRepoDir = 'D:\NovaPOS\installer',
  [string]$BackupRestoreDoc  = 'D:\NovaPOS\docs\ds6-backup-restore.md',
  [string]$LogFile
)
$ErrorActionPreference='Stop'
$LOG = New-Object System.Collections.Generic.List[string]
function W($m){ $LOG.Add($m); Write-Host $m }
function Flush-Log{ if($LogFile){ $LOG | Set-Content $LogFile -Encoding UTF8 } }
function Fail($m){ W "BUNDLE FAILED: $m"; Flush-Log; throw $m }

# الملفات الخمسة المسموح تغييرها في هذه المرحلة (الإصلاح) — خارجها أي تغيير = فشل
$allowedChanged = @(
  'BACKUP-RESTORE.md',
  'installer\New-ReleaseBundle.ps1',
  'installer\Install-NovaPOS.ps1',
  'installer\Uninstall-NovaPOS.ps1',
  'installer\Verify-InstalledNovaPOS.ps1'
)

if (-not $SourceBundle)     { Fail 'SourceBundle is required.' }
if (-not $SourceManifest)   { Fail 'SourceManifest is required.' }
if (-not $OutDir)           { Fail 'OutDir is required.' }
if (-not $OutManifestName)  { Fail 'OutManifestName is required.' }
if (Test-Path $OutDir)      { Fail "OutDir already exists: $OutDir — refusing to overwrite an existing artifact." }
if (-not (Test-Path $BackupRestoreDoc)) { Fail "DS-6 document missing: $BackupRestoreDoc" }

W "=== New-ReleaseBundle ($(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) ==="
W "source bundle : $SourceBundle"
W "source manifest: $SourceManifest"
W "output        : $OutDir  (manifest: $OutManifestName)"

# 1) تحليل بيان الأساس
$src = @{}
foreach ($l in Get-Content $SourceManifest) {
  if ($l -match '^([0-9A-F]{64})\s{2}(\d+)\s{2}(.+)$') { $src[$matches[3]] = @{ sha=$matches[1]; size=[long]$matches[2] } }
}
W "source manifest entries = $($src.Count)"
if ($src.Count -eq 0) { Fail 'source manifest parsed to zero entries — bad manifest?' }

# 2) نسخ حزمة الأساس (غير مُمَسة — نسخ فقط)
New-Item -ItemType Directory -Path $OutDir | Out-Null
robocopy $SourceBundle $OutDir /E /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { Fail "payload copy failed with robocopy exit $LASTEXITCODE" }
W "payload copy robocopy exit=$LASTEXITCODE (0-7 = success)"

# 3) تطبيق الملفات الخمسة المُصحَّحة من المستودع
Copy-Item -LiteralPath $BackupRestoreDoc (Join-Path $OutDir 'BACKUP-RESTORE.md') -Force
if (-not (Test-Path (Join-Path $OutDir 'installer'))) { New-Item -ItemType Directory -Path (Join-Path $OutDir 'installer') | Out-Null }
Copy-Item -LiteralPath (Join-Path $InstallerRepoDir 'pack\New-ReleaseBundle.ps1') (Join-Path $OutDir 'installer\New-ReleaseBundle.ps1') -Force
foreach ($s in @('Install-NovaPOS.ps1','Uninstall-NovaPOS.ps1','Verify-InstalledNovaPOS.ps1')) {
  Copy-Item -LiteralPath (Join-Path $InstallerRepoDir "install\$s") (Join-Path $OutDir "installer\$s") -Force
}
W "stage-3 (fix) files applied: BACKUP-RESTORE.md + installer\ (4 scripts)"

# 3b) استبدال بيان الأساس الموروث (إن وُجد '*-manifest.txt' مختلف عن بيان المرشح)
#     — سلسلة الإثبات: كل حزمة تحمل بيانها هي؛ البيان القديم لا يُورَّث كحمولة.
$oldManifests = @(Get-ChildItem -LiteralPath $OutDir -File | Where-Object { $_.Name -like '*-manifest.txt' -and $_.Name -ne $OutManifestName })
foreach ($om in $oldManifests) {
  Remove-Item -LiteralPath $om.FullName -Force
  W ("removed inherited manifest: {0} (replaced by {1})" -f $om.Name, $OutManifestName)
}

# 4) تجزئة واحدة: تحقق الموروث + عدّ التغييرات + ابنِ البيان الجديد
$files = @(Get-ChildItem $OutDir -Recurse -File | Sort-Object { $_.FullName.Substring($OutDir.Length + 1) })
$lines   = New-Object System.Collections.Generic.List[string]
$sum     = [long]0
$mismatch= New-Object System.Collections.Generic.List[string]  # تغييرات خارج الخمسة
$changed = New-Object System.Collections.Generic.List[string]  # تغييرات ضمن الخمسة
$added   = New-Object System.Collections.Generic.List[string]  # ملفات جديدة غير موجودة في الأساس
foreach ($f in $files) {
  $rel = $f.FullName.Substring($OutDir.Length + 1)
  $h = (Get-FileHash $f.FullName -A SHA256).Hash
  $sum += $f.Length
  if ($src.ContainsKey($rel)) {
    $differs = ($h -ne $src[$rel].sha -or $f.Length -ne $src[$rel].size)
    if ($differs) {
      if ($allowedChanged -contains $rel) { $changed.Add($rel); W ("CHANGED (allowed): {0}" -f $rel) }
      else { $mismatch.Add($rel); W ("MISMATCH vs source (NOT an allowed file): {0}" -f $rel) }
    }
  } else {
    $added.Add($rel); W ("ADDED (new): {0}  {1} B" -f $rel, $f.Length)
  }
  $lines.Add(( "{0}  {1}  {2}" -f $h, $f.Length, $rel ))
}
$present = @{}; foreach($f in $files){ $present[$f.FullName.Substring($OutDir.Length + 1)]=$true }
$missing = @($src.Keys | Where-Object { -not $present.ContainsKey($_) })
foreach ($m in $missing) { W "MISSING from bundle: $m" }
W ("payload check: inherited={0}/{1} missing={2} added={3} changed={4} mismatch={5} (expect changed 0-or-5, added 0, mismatch 0, missing 0)" -f ($src.Count - $missing.Count), $src.Count, $missing.Count, $added.Count, $changed.Count, $mismatch.Count)

# 5) بناء الترويسة والبيان
$hdr = New-Object System.Collections.Generic.List[string]
$hdr.Add( ($ManifestHeader -f (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) )
$hdr.Add("# root=$OutDir")
$hdr.Add("# files=$($files.Count)  bytes=$sum")
$hdr.Add( $BaseNote )
$hdr.Add("# format: SHA256 <2sp> size <2sp> relative-path")
$all = $hdr + $lines
$all | Set-Content (Join-Path $OutDir $OutManifestName) -Encoding UTF8

$mf = Get-Item (Join-Path $OutDir $OutManifestName)
$mfSha = (Get-FileHash $mf.FullName -A SHA256).Hash
W "$OutManifestName = $($mf.Length) B sha256=$mfSha"
W ("BUNDLE RESULT: files={0} bytes={1} missing={2} added={3} changed={4} mismatch={5}" -f $files.Count, $sum, $missing.Count, $added.Count, $changed.Count, $mismatch.Count)

$fail = ($missing.Count -gt 0 -or $mismatch.Count -gt 0 -or $added.Count -ne 0 -or ($changed.Count -ne 0 -and $changed.Count -ne 5))
W "OVERALL: $(if($fail){'FAIL'}else{'PASS'})"
Flush-Log
if ($fail) { exit 1 } else { exit 0 }
