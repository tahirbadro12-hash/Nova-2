﻿<#
.SYNOPSIS
  Install-NovaPOS.ps1 — المرحلة 3/إصلاح: تثبيت NovaPOS (PowerShell بدل MSI — قرار المالك).
.DESCRIPTION
  يثبّت حزمة التوزيع (rc-r6 أو ما يعادلها) إلى مجلد التثبيت (افتراضيًا Program Files
  مع إمكانية التخصيص). ملفات البرنامج منفصلة عن بيانات المستخدم: هذا السكربت
  **لا يقرأ ولا يكتب ولا يحذف `%LOCALAPPDATA%\NovaPOS` ولا أي مجلد بيانات إطلاقًا**
  (تجهيز البيانات في مسار بيانات معزول اختياري فقط، وبرفض إلزامي لمسار الإنتاج).

  **سلامة التراجع (ضمانة ضد فشل نسخ/تحقق/تبديل وانقطاع):** التثبيت يجري بترتيب
  staging → swap → verify، ولا يفترض أن تبديل المجلدات ذرّيًّا على Windows:
    • ينسخ إلى مجلد ساحة مؤقت (.staging-<طابع>) ثم يتحقق منه بالتجزئة كاملةً.
    • ينقل مجلد التثبيت القائم باسم مؤقت (.previous-<طابع>) — يُحفظ ولا يُحذف.
    • ينقل الساحة إلى مجلد التثبيت، ثم يتحقق مرة أخيرة بالتجزئة.
    • فشل أي خطوة ⇐ استرجاع مُتحقَّق (وليس مجرد rename أعمى). حالة ملتبسة ⇐
      توقّف صريح مع الإبقاء على كل شيء (لا يُحذف ملف في حالة الاشتباه).
  قاعدة الجدار الناري: معطَّلة افتراضيًا — لا تُنشأ قاعدة إلا بـ`-AddFirewallRule`
  **+** `-ConfirmOwnerFirewallPermission` **+** صلاحيات admin (قرار المالك 5).
.NOTES
  ممنوع: تشغيل التطبيق · لمس قاعدة الإنتاج · تعديل الحزم · حذف بيانات المستخدم.
#>
[CmdletBinding()]
param(
  [string]$InstallDir,          # مجلد التثبيت — قابل للتخصيص (افتراضيًا Program Files؛ admin)
  [string]$DataDirectory,       # مسار بيانات معزول للاختبارات فقط — يُرفض إن كان/أحاط بالإنتاج
  [string]$SourceDir,           # مجلد الحزمة المصدر (افتراضيًا: جذر الحزمة المضمَّنة للسكربت)
  [switch]$SkipShortcut,        # تخطي الاختصار (لاختبارات الجافة)
  [string]$ShortcutDirectory,   # مجلد اختصار معزول للاختبارات (افتراضيًّا Programs الحقيقي)
  [switch]$SkipDataProvisioning,# تخطي تجهيز مسار البيانات المعزول (الافتراضي السلوك الإنتاجي)
  [switch]$AddFirewallRule,                     # إنشاء قاعدة جدار (لن يُنفَّذ دون الإقرار)
  [switch]$ConfirmOwnerFirewallPermission,      # تأكيد إذن المالك المستقل
  [string]$TestManifestName,    # للاختبارات فقط: اسم بيان الحزمة (يكتشف '*-manifest.txt' تلقائيًّا)
  [string]$LogFile              # سجل اختياري
)
$ErrorActionPreference='Stop'
$LOG = New-Object System.Collections.Generic.List[string]
function W($m){ $LOG.Add($m); Write-Host $m }
function Flush-Log{ if($LogFile){ $LOG | Set-Content $LogFile -Encoding UTF8 } }
function Fail($m){ W "INSTALL FAILED: $m"; Flush-Log; throw $m }

# ---- تطبيع مسارات الإنتاج المرفوضة لمسار البيانات (حارس ضد أي لمس للإنتاج) ----
function Get-ProductionDataDir{
  $lad = [Environment]::GetFolderPath([Environment+SpecialFolder]::LocalApplicationData)
  if([string]::IsNullOrWhiteSpace($lad)){ return $null }
  return [IO.Path]::GetFullPath((Join-Path $lad 'NovaPOS')).TrimEnd('\')
}
function Test-IsProtectedDataPath($candidate,[string[]]$blockedRoots){
  if([string]::IsNullOrWhiteSpace($candidate)){ return $true }          # فارغ = محمي
  try { $full=[IO.Path]::GetFullPath($candidate).TrimEnd('\') } catch { return $true }
  foreach($r in $blockedRoots){
    if([string]::IsNullOrWhiteSpace($r)){ continue }
    $rf=$r.TrimEnd('\')
    if($full.Equals($rf,[StringComparison]::OrdinalIgnoreCase)){ return $true }         # الإنتاج نفسه
    if($full.StartsWith($rf+'\',[StringComparison]::OrdinalIgnoreCase)){ return $true } # داخل الإنتاج
  }
  return $false
}

if (-not $InstallDir)   { $InstallDir   = Join-Path $env:ProgramFiles 'NovaPOS' }
if (-not $SourceDir)    { $SourceDir    = Split-Path $PSScriptRoot -Parent }
$InstallDir   = [IO.Path]::GetFullPath($InstallDir)
$SourceDir    = [IO.Path]::GetFullPath($SourceDir)
$prodDataDir  = Get-ProductionDataDir
# مسارات بيانات محمية: مجلد الإنتاج نفسه + ما تحته + جذور Windows الحساسة
$blockedRoots = @($prodDataDir, $env:LOCALAPPDATA, $env:APPDATA, $env:USERPROFILE, $env:SystemRoot, $env:ProgramFiles)

W "=== NovaPOS Install ($(Get-Date -Format 'yyyy-MM-dd HH:mm:ss')) ==="
W "source     : $SourceDir"
W "install dir: $InstallDir"
if ($DataDirectory) {
  W "data dir   : $DataDirectory  (isolated test provisioning)"
  if (Test-IsProtectedDataPath $DataDirectory $blockedRoots) {
    Fail "refusing -DataDirectory '$DataDirectory': it is/inside a protected path (production data or a system root). This installer never provisions there."
  }
} else {
  W "data dir   : (none — no user-data provisioning; program files only)"
}

# ---- حارس الانقطاع: رفض أي حالة سابقة ملتبسة (ساحة/نسخة سابقة/تثبيت ناقص) ----
$stamp    = Get-Date -Format 'yyyyMMdd-HHmmss'
$staging  = "$InstallDir.staging-$stamp"
$previous = "$InstallDir.previous-$stamp"
$parent   = Split-Path $InstallDir -Parent
if (Test-Path $parent) {
  $leftovers = @(Get-ChildItem -LiteralPath $parent -Directory -ErrorAction SilentlyContinue |
                 Where-Object { $_.Name -like "$(Split-Path $InstallDir -Leaf).staging-*" -or $_.Name -like "$(Split-Path $InstallDir -Leaf).previous-*" })
  if ($leftovers.Count -gt 0) {
    W "LEFTOVER state from a prior run detected — inspecting before touching anything:"
    foreach($l in $leftovers){ W "  leftover: $($l.FullName)" }
    Fail "a previous install/upgrade left staging/previous folders behind (interrupted or failed run). Nothing was changed and nothing was deleted. Resolve manually: if a '.previous-*' folder holds your working install, restore it by renaming it back to '$InstallDir'; then remove the leftover folders. Re-run only when the install dir is clean."
  }
}

# 1) شروط الحزمة
$manifestName = $TestManifestName
if (-not $manifestName) {
  $mf = @(Get-ChildItem -LiteralPath $SourceDir -File -Filter '*-manifest.txt' -ErrorAction SilentlyContinue)
  if ($mf.Count -ne 1) { Fail "expected exactly one '*-manifest.txt' in bundle '$SourceDir', found $($mf.Count)." }
  $manifestName = $mf[0].Name
}
$manifest = Join-Path $SourceDir $manifestName
foreach ($p in @($manifest, (Join-Path $SourceDir 'BACKUP-RESTORE.md'), (Join-Path $SourceDir 'NovaPOS.App.dll'))) {
  if (-not (Test-Path -LiteralPath $p)) { Fail "bundle incomplete — missing: $p" }
}
$manifestSha = (Get-FileHash -LiteralPath $manifest -A SHA256).Hash
W "bundle manifest: $manifestName sha256=$manifestSha"

# 2) رفض أثناء تشغيل التطبيق
$running = @(Get-Process -Name 'NovaPOS.App','NovaPOS.Server' -ErrorAction SilentlyContinue)
if ($running.Count -gt 0) { Fail "NovaPOS is running (pids: $($running.Id -join ', ')) — close it before installing." }

# 3) قابلية كتابة المجلد الأب (Program Files يحتاج admin) — بلا إنشاء مجلد التثبيت النهائي
try {
  if (-not (Test-Path -LiteralPath $parent)) { New-Item -ItemType Directory -Path $parent -Force | Out-Null }
  $probe = Join-Path $parent ".write-probe-$stamp"
  Set-Content -LiteralPath $probe 'ok' -ErrorAction Stop; Remove-Item -LiteralPath $probe -Force
} catch {
  Fail "install parent not writable ($parent) — run PowerShell as administrator or choose another -InstallDir. $_"
}

# 4) تجهيز مسار البيانات المعزول (اختياري — للاختبارات). يُنشأ ويُنسخ فيه فقط، ولا يُمس الإنتاج أصلًا.
$preUpgradeBackup = $null
if ($DataDirectory -and -not $SkipDataProvisioning) {
  $db = Join-Path $DataDirectory 'nova_pos.db'
  if (Test-Path -LiteralPath $db) {
    $bakDir = Join-Path (Join-Path $DataDirectory 'Backups') "pre-install-$stamp"
    New-Item -ItemType Directory -Path $bakDir -Force | Out-Null
    Copy-Item -LiteralPath $db (Join-Path $bakDir 'nova_pos.db')
    $preUpgradeBackup = "$bakDir\nova_pos.db"
    W "pre-upgrade backup: $preUpgradeBackup"
  } else {
    New-Item -ItemType Directory -Path $DataDirectory -Force | Out-Null
    W "isolated data dir created: $DataDirectory"
  }
}

# 5) STAGE — نسخ كامل إلى الساحة ثم تحقق بالتجزئة كاملةً قبل أي تبديل
W "staging copy -> $staging"
robocopy $SourceDir $staging /E /NFL /NDL /NJH /NJS /NP | Out-Null
if ($LASTEXITCODE -ge 8) { Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue; Fail "staging copy failed with robocopy exit $LASTEXITCODE" }
try {
  $entries = @{}
  foreach ($l in Get-Content -LiteralPath $manifest) { if ($l -match '^([0-9A-F]{64})\s{2}(\d+)\s{2}(.+)$') { $entries[$matches[3]] = @{ sha=$matches[1]; size=[long]$matches[2] } } }
  foreach ($rel in $entries.Keys) {
    $fp = Join-Path $staging $rel
    if (-not (Test-Path -LiteralPath $fp)) { throw "staging missing: $rel" }
    if ((Get-Item -LiteralPath $fp).Length -ne $entries[$rel].size) { throw "staging size mismatch: $rel" }
    if ((Get-FileHash -LiteralPath $fp -A SHA256).Hash -ne $entries[$rel].sha) { throw "staging hash mismatch: $rel" }
  }
  W "staging verified: $($entries.Count)/$($entries.Count) entries match manifest (0 mismatch)"
} catch {
  Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
  Fail "staging verification failed — staged copy removed, install dir untouched. $_"
}

# 6) SWAP — نقلان مُتحقَّق منهما (لا يفترذ ذرّية على Windows)
$hadInstall = Test-Path -LiteralPath $InstallDir
if ($hadInstall) {
  W "preserving current install -> $previous"
  try { Move-Item -LiteralPath $InstallDir -Destination $previous -ErrorAction Stop }
  catch {
    if (Test-Path -LiteralPath $InstallDir) {   # الاسم القديم باقٍ = النقل لم يبدأ → حالة نظيفة
      Remove-Item -LiteralPath $staging -Recurse -Force -ErrorAction SilentlyContinue
      Fail "could not move current install aside ($_). The existing install is intact and was NOT deleted. Resolve the lock/permission and retry."
    }
    Fail "AMBIGUOUS: moving '$InstallDir' to '$previous' errored AND the original path is now missing ($_). Nothing was deleted. Inspect both paths manually and restore '$previous' if needed."
  }
}
W "activating staged copy -> $InstallDir"
try { Move-Item -LiteralPath $staging -Destination $InstallDir -ErrorAction Stop }
catch {
  $activated = Test-Path -LiteralPath $InstallDir
  if (-not $activated -and $hadInstall -and (Test-Path -LiteralPath $previous)) {
    try {
      Move-Item -LiteralPath $previous -Destination $InstallDir -ErrorAction Stop
      W "ROLLBACK OK: previous install restored to $InstallDir"
      Fail "activation failed ($_); the previous install was restored and verified-by-move. Staging removed. Retry after fixing the cause."
    } catch {
      Fail "AMBIGUOUS: activation failed AND rollback failed ($_). Previous install preserved at '$previous' and staging at '$staging'. Nothing was deleted — resolve manually (rename '$previous' back to '$InstallDir')."
    }
  }
  Fail "AMBIGUOUS: activation failed ($_). Inspect '$InstallDir' and '$previous' manually. Nothing was deleted automatically."
}

# 7) VERIFY — تحقق أخير بالتجزئة من النسخة المفعَّلة
try {
  $bad = 0
  foreach ($rel in $entries.Keys) {
    $fp = Join-Path $InstallDir $rel
    if (-not (Test-Path -LiteralPath $fp)) { $bad++; continue }
    if ((Get-FileHash -LiteralPath $fp -A SHA256).Hash -ne $entries[$rel].sha) { $bad++ }
  }
  if ($bad -gt 0) { throw "$bad installed file(s) failed final hash verification" }
  W "final verification: $($entries.Count)/$($entries.Count) installed files match manifest"
} catch {
  if ($hadInstall -and (Test-Path -LiteralPath $previous)) {
    try {
      Remove-Item -LiteralPath $InstallDir -Recurse -Force -ErrorAction Stop
      Move-Item -LiteralPath $previous -Destination $InstallDir -ErrorAction Stop
      W "ROLLBACK OK (post-verify): previous install restored."
    } catch { Fail "AMBIGUOUS: post-verify failed AND rollback failed ($_). Previous preserved at '$previous'. Nothing else deleted." }
  }
  Fail "final verification failed — $_"
}
if ($hadInstall) { W "previous install preserved at: $previous (kept as safety copy — remove manually after successful validation)" }

# 8) JARSAR — رفض الجدار افتراضيًا (قرار المالك 5)
$firewallAdded = $false
if ($AddFirewallRule) {
  if (-not $ConfirmOwnerFirewallPermission) { W "FIREWALL RULE REFUSED: -AddFirewallRule requires -ConfirmOwnerFirewallPermission. Skipped." }
  else {
    $id=[Security.Principal.WindowsIdentity]::GetCurrent()
    $adminRole=[Security.Principal.WindowsBuiltInRole]::Administrator
    if (-not (New-Object Security.Principal.WindowsPrincipal($id)).IsInRole($adminRole)) { W "FIREWALL RULE REFUSED: administrator rights required. Skipped." }
    else {
      $exe = Join-Path $InstallDir 'server\NovaPOS.Server.exe'
      netsh advfirewall firewall add rule name="NovaPOS Server" dir=in action=allow protocol=TCP localport=3000 program="$exe" enable=yes profile=private,domain | Out-Null
      $firewallAdded = ($LASTEXITCODE -eq 0); W "firewall rule created: $firewallAdded"
    }
  }
} else { W "firewall: NOT TOUCHED (default off — separate explicit owner permission required)." }

# 9) اختصار القائمة (مع `-ShortcutDirectory` معزول للاختبارات؛ افتراضيًّا Programs الحقيقي)
$lnkPath = $null
if (-not $SkipShortcut) {
  $dir = if ($ShortcutDirectory) { $ShortcutDirectory } else { [Environment]::GetFolderPath('Programs') }
  New-Item -ItemType Directory -Path $dir -Force | Out-Null
  $lnkPath = Join-Path $dir 'NovaPOS.lnk'
  $sh = New-Object -ComObject WScript.Shell
  $lnk = $sh.CreateShortcut($lnkPath)
  $lnk.TargetPath = Join-Path $InstallDir 'NovaPOS.App.exe'
  $lnk.WorkingDirectory = $InstallDir
  $lnk.Description = 'NovaPOS Desktop 1.0.0'
  $lnk.Save()
  W "shortcut: $lnkPath"
}

# 10) سجل التثبيت
$ver = (Get-Item -LiteralPath (Join-Path $InstallDir 'NovaPOS.App.dll')).VersionInfo
$record = [ordered]@{
  product=$ver.ProductName; productVersion=$ver.ProductVersion; fileVersion=$ver.FileVersion
  installedAt=(Get-Date -Format 'yyyy-MM-dd HH:mm:ss'); installDir=$InstallDir
  dataDirectory=$(if ($DataDirectory -and -not $SkipDataProvisioning) { $DataDirectory } else { $null })
  sourceBundleManifest=$manifestName; manifestSha256=$manifestSha
  installedFiles=$entries.Count
  preUpgradeBackup=$preUpgradeBackup; firewallRuleAdded=$firewallAdded; shortcut=$lnkPath
  previousInstall=$(if ($hadInstall) { $previous } else { $null })
  stage='Stage 3 (installer) — NOT a release approval; INS-1/A-8 remain open'
}
$record | ConvertTo-Json | Set-Content -LiteralPath (Join-Path $InstallDir 'install-record.json') -Encoding UTF8
W "install record: $InstallDir\install-record.json"
W "INSTALL DONE — next: Verify-InstalledNovaPOS.ps1 -InstallDir `"$InstallDir`""
Flush-Log
exit 0
