﻿<#
.SYNOPSIS
  Verify-InstalledNovaPOS.ps1 — المرحلة 3: الفحص ما بعد التثبيت (جديد — ليس سكربت
  المنتج القديم verify-installed-windows.ps1؛ الخطة تنص على أنه ليس معيارًا).
.DESCRIPTION
  يعيد تجزئة SHA-256 لكل ملف مثبت مقابل r5-manifest.txt (سلسلة الإثبات: rc-r4 →
  rc-r5 → المثبت)، ويتحقق من إصدار 1.0.0 وسجل التثبيت، ويبلّغ عن مجلد البيانات
  دون لمسه. لا يشغّل التطبيق إطلاقًا (التشغيل يتطلب جلسة اختبار معتمدة).
  النشر مشروط بـ 0 اختلاف.
#>
[CmdletBinding()]
param(
  [string]$InstallDir,
  [string]$ManifestPath,
  [string]$OutJson
)
$ErrorActionPreference='Stop'

if (-not $InstallDir)   { $InstallDir   = Join-Path $env:ProgramFiles 'NovaPOS' }
if (-not $ManifestPath) {
  # اكتشاف تلقائي لبيان الحزمة '*-manifest.txt' (r5/r6/…) بدل تسمية ثابتة
  $mf = @(Get-ChildItem -LiteralPath $InstallDir -File -Filter '*-manifest.txt' -ErrorAction SilentlyContinue)
  if ($mf.Count -ne 1) { throw "expected exactly one '*-manifest.txt' in '$InstallDir', found $($mf.Count) — pass -ManifestPath explicitly." }
  $ManifestPath = $mf[0].FullName
}

Write-Host "=== NovaPOS Post-Install Verify (Stage 3) - $(Get-Date -Format 'yyyy-MM-dd HH:mm:ss') ==="
Write-Host "install dir: $InstallDir"
Write-Host "manifest   : $ManifestPath"

if (-not (Test-Path $InstallDir))   { throw "install dir missing: $InstallDir" }
if (-not (Test-Path $ManifestPath)) { throw "manifest missing: $ManifestPath" }

# 1. full hash verification of every installed file against the bundle manifest
$entries = @{}
foreach ($l in Get-Content $ManifestPath) {
  if ($l -match '^([0-9A-F]{64})\s{2}(\d+)\s{2}(.+)$') { $entries[$matches[3]] = @{ sha = $matches[1]; size = [long]$matches[2] } }
}
Write-Host "manifest entries = $($entries.Count)"

$ok = 0; $missing = 0; $hashBad = 0; $sizeBad = 0
$problems = New-Object System.Collections.Generic.List[string]
foreach ($rel in $entries.Keys) {
  $fp = Join-Path $InstallDir $rel
  if (-not (Test-Path -LiteralPath $fp)) { $missing++; $problems.Add("MISSING  $rel"); continue }
  $fi = Get-Item -LiteralPath $fp
  if ($fi.Length -ne $entries[$rel].size) { $sizeBad++; $problems.Add("SIZE     $rel expected=$($entries[$rel].size) actual=$($fi.Length)"); continue }
  $h = (Get-FileHash -LiteralPath $fp -A SHA256).Hash
  if ($h -ne $entries[$rel].sha) { $hashBad++; $problems.Add("HASH     $rel expected=$($entries[$rel].sha) actual=$h"); continue }
  $ok++
}
foreach ($p in $problems) { Write-Host "  $p" }
Write-Host "hash check: ok=$ok  missing=$missing  sizeBad=$sizeBad  hashBad=$hashBad"

# 2. version check (ProductVersion must remain 1.0.0 — never modified)
$ver = (Get-Item (Join-Path $InstallDir 'NovaPOS.App.dll')).VersionInfo
$verOk = ($ver.ProductName -eq 'Nova POS' -and $ver.ProductVersion -eq '1.0.0' -and $ver.FileVersion -eq '1.0.0.0')
Write-Host "version: Product='$($ver.ProductName)' ProductVersion='$($ver.ProductVersion)' FileVersion='$($ver.FileVersion)' => $(if ($verOk) { 'MATCH' } else { 'MISMATCH' })"

# 3. install record
$recordPath = Join-Path $InstallDir 'install-record.json'
$recordOk = Test-Path $recordPath
$record = if ($recordOk) { Get-Content $recordPath -Raw | ConvertFrom-Json } else { $null }
Write-Host "install record: present=$recordOk firewallRuleAdded=$(if ($record) { $record.firewallRuleAdded } else { 'n/a' })"

# 4. data directory — REPORT ONLY, never touched
$dbPath = Join-Path $(if ($record -and $record.dataDirectory) { $record.dataDirectory } else { Join-Path $env:LOCALAPPDATA 'NovaPOS' }) 'nova_pos.db'
Write-Host "data dir db exists=$(Test-Path $dbPath) (reported only — not touched): $dbPath"

# 5. launch check — SKIPPED by design in this stage (owner constraint: no NovaPOS.exe)
Write-Host "launch check: SKIPPED (requires an explicitly approved stage test session)"

$result = [ordered]@{
  checkedAt       = (Get-Date -Format 'yyyy-MM-dd HH:mm:ss')
  installDir      = $InstallDir
  manifestEntries = $entries.Count
  ok              = $ok
  missing         = $missing
  sizeBad         = $sizeBad
  hashBad         = $hashBad
  versionMatch    = $verOk
  installRecord   = $recordOk
  firewallCreated = $(if ($record) { $record.firewallRuleAdded } else { $null })
  launchCheck     = 'SKIPPED (owner constraint)'
  overall         = $(if ($missing -eq 0 -and $sizeBad -eq 0 -and $hashBad -eq 0 -and $verOk -and $recordOk) { 'PASS' } else { 'FAIL' })
}
if ($OutJson) { $result | ConvertTo-Json | Set-Content $OutJson -Encoding UTF8 }
Write-Host "OVERALL: $($result.overall)"
if ($result.overall -eq 'PASS') { exit 0 } else { exit 1 }
