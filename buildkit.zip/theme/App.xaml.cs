using System.IO;
using System.Text.Json;
using System.Windows;
using Microsoft.Data.Sqlite;
using NovaPOS.Core.Interfaces;
using NovaPOS.Core.Printing;
using NovaPOS.Core.Services;
using NovaPOS.Data;
using NovaPOS.Data.Backup;
using NovaPOS.Data.CartDrafts;
using NovaPOS.Data.Database;
using NovaPOS.Data.Journal;
using NovaPOS.Data.Repositories;
using NovaPOS.App.Services;
using NovaPOS.Infrastructure.Printing;
using NovaPOS.Infrastructure.System;
using NovaPOS.Network.Contracts;
using NovaPOS.Network.Remote;
using NovaPOS.Network.Security;

namespace NovaPOS.App;

public partial class App : Application
{
    public static IUnitOfWork? UnitOfWork { get; private set; }
    public static IAuthService? AuthService { get; private set; }
    public static SessionManager? SessionManager { get; private set; }

    /// <summary>
    /// A8: حارس الصلاحيات — يُركَّب مرة واحدة فوق جلسة الدخول ومستودع الإعدادات
    /// ويُمرَّر إلى كل خدمة حساسة في مسارَي الوضعين. الإنتاج لا يتركه null أبدًا
    /// (قرار5): المعامل الاختياري في توقيعات الخدمات محفوظ للاختبارات المحموظة فقط.
    /// </summary>
    public static PermissionGuard? PermissionGuard { get; private set; }

    public static PurchaseService? PurchaseService { get; private set; }

    /// <summary>
    /// A7: خدمة حساب العميل (دفتر الأرصدة وسندات القبض) — الوضع المحلي فقط.
    /// في وضع الشبكة تبقى null: دعم LAN مؤجَّل إلى تصميم/اعتماد منفصلين (قرار D2 أ)
    ///، وصفحات الحساب تتحقق وتعرض رسالة وظيفية بدل استدعاء null.
    /// </summary>
    public static CustomerAccountService? CustomerAccountService { get; private set; }

    /// <summary>A9 (محلي فقط): سجل الفواتير — تبقى null في وضع الشبكة (رسالة وظيفية).</summary>
    public static SalesHistoryService? SalesHistoryService { get; private set; }

    /// <summary>A9 (محلي فقط): الإلغاء والمرتجع — تبقى null في وضع الشبكة (رسالة وظيفية).</summary>
    public static SalesReversalService? SalesReversalService { get; private set; }

    /// <summary>
    /// A14 (محلي فقط): الصندوق والمصروفات وإغلاق اليوم وإسناد المبيعات — تبقى
    /// null في وضع الشبكة (رسالة وظيفية نمط A7/A9): لا LAN جديد في هذه المرحلة.
    /// </summary>
    public static ExpenseService? ExpenseService { get; private set; }

    /// <summary>A14 (محلي فقط): تشغيل الصندوق وحركة النقد.</summary>
    public static CashRegisterService? CashRegisterService { get; private set; }

    /// <summary>A14 (محلي فقط): إغلاق اليوم وتقريره.</summary>
    public static DayCloseService? DayCloseService { get; private set; }

    /// <summary>A14 (محلي فقط): إسناد الفاتورة لأمينها (D-3) — الكتابة بعد نجاح البيع من الواجهة.</summary>
    public static SaleAttributionService? SaleAttributionService { get; private set; }

    /// <summary>
    /// A15 (محلي فقط): خدمة التقارير الجديدة (مبيعات/ربحية/مخزون/مصروفات/إسناد)
    /// — <c>ReportService</c> المحمي لم يُلمس ولم يُستدعَ. null في وضع الشبكة
    /// (رسالة وظيفية): صفر تغيير LAN.
    /// </summary>
    public static StoreReportsService? StoreReportsService { get; private set; }

    /// <summary>
    /// A16 (محلي فقط): إعدادات المتجر في القاعدة (اسم/عملة/حدّ الخصم) —
    /// البوابة settings.manage داخل الخدمة · null في وضع الشبكة برسالة وظيفية.
    /// </summary>
    public static StoreSettingsService? StoreSettingsService { get; private set; }

    /// <summary>
    /// A17 (محلي فقط): منسّق لوحة التحكم فوق خدمات A14/A15/A9 القائمة — بلا
    /// معادلات جديدة ولا كتالوج · null في وضع الشبكة (رسالة وظيفية) صفر تغيير LAN.
    /// </summary>
    public static DashboardService? DashboardService { get; private set; }

    /// <summary>
    /// A16 (محلي فقط): عمليات النسخ الاحتياطي والاستعادة فوق خدمات A12 بلا
    /// تغييرها — البوابة backup.manage داخل الخدمة · null في وضع الشبكة.
    /// </summary>
    public static BackupOperationsService? BackupOperationsService { get; private set; }

    /// <summary>
    /// A10 (قرارات د1/د2): خدمة تعليق/استئناف سلة البيع — مسوّدات JSON محلية
    /// على الجهاز (بلا SQLite وبلا ترحيل) تُركَّب في **الوضعين** المحلي وLAN
    /// لأنها حالة جهاز لا بيانات أعمال: صفر نقاط نهاية خادمية وصفر أثر على LAN-5،
    /// والإرسال الأخير يبقى عبر وحدة العمل العادية في كل وضع.
    /// </summary>
    public static CartDraftService? CartDraftService { get; private set; }

    /// <summary>
    /// A8-3: خدمة إدارة المستخدمين — تُركَّب في الوضعين بالحارس الإلزامي (المُنشئ
    /// يستثني null) — الواجهة مرآة عرض فقط وليست مصدر الصلاحية.
    /// </summary>
    public static UserService? UserService { get; private set; }

    /// <summary>
    /// A11 (قرار3/6): إعدادات الطباعة على هذا الجهاز — ملف JSON محلي
    /// (<c>print-settings.json</c>) بلا أي جدول أو ترحيل. تُقرأ وتُحفظ من
    /// قسم الطباعة في الإعدادات.
    /// </summary>
    public static IPrintSettingsStore? PrintSettingsStore { get; private set; }

    /// <summary>
    /// A11: خدمة الطباعة والفواتير — تُركَّب في **الوضعين** (الطباعة على الجهاز
    /// الذي يبيع، والبيانات في اليد مباشرة بعد البيع): ناقل حقيقي (حراري/ورقي)
    /// + مصدر اسم المتجر من قراءة <c>Settings.store_name</c> فقط.
    /// </summary>
    public static InvoicePrintingService? InvoicePrintingService { get; private set; }

    protected override void OnStartup(StartupEventArgs e)
    {
        base.OnStartup(e);

        // A18 (الثيم والخط): إعداد جهاز محلي بنمط A11 (print-settings) تمامًا —
        // يُطبَّق قبل إنشاء أي نافذة، وأي فشل يعود بالافتراضي (فاتح + Cairo):
        // المظهر تجميلي ولا يوقف أحدًا.
        ThemeManager.Bootstrap(this);

        string connectionString;
        try
        {
            // Fixed per-user location: never the working directory, never the
            // executable directory, never Program Files.
            var targetPath = DatabasePathResolver.GetDatabasePath();
            var legacyCandidates = new[]
            {
                Path.Combine(AppDomain.CurrentDomain.BaseDirectory, DatabasePathResolver.DatabaseFileName),
                Path.Combine(Environment.CurrentDirectory, DatabasePathResolver.DatabaseFileName)
            };

            var prepared = DatabaseMigrator.PrepareDatabase(targetPath, legacyCandidates);
            DatabaseMigrator.EnsureUsable(prepared.DatabasePath);

            Directory.CreateDirectory(Path.GetDirectoryName(prepared.DatabasePath)!);
            connectionString = DatabasePathResolver.BuildConnectionString(prepared.DatabasePath);

            var initializer = new DatabaseInitializer(connectionString);
            initializer.Initialize();
            initializer.SeedData();
        }
        catch (Exception ex) when (ex is DatabaseMigrationException
                                       or IOException
                                       or UnauthorizedAccessException
                                       or SqliteException)
        {
            // Never fall back to creating a fresh database when the existing one
            // cannot be opened: stop with a clear message instead.
            MessageBox.Show(
                "تعذر تهيئة قاعدة البيانات:\n\n" + ex.Message,
                "Nova POS - خطأ في قاعدة البيانات",
                MessageBoxButton.OK,
                MessageBoxImage.Error);
            Shutdown(-1);
            return;
        }

        var passwordHasher = new PasswordHasher();

        // --------------------------------------------------------------------------------
        // LAN mode (LAN-4): a lanClient.json beside the database turns this device into a
        // client of a REMOTE NovaPOS server. Business data then crosses the wire — reads
        // as authenticated GETs, writes journal-first with an Idempotency-Key (design §8),
        // so no retry or resend can execute a sale/purchase twice. The local SQLite keeps
        // only what belongs to the device: the write-ahead journal, the login accounts,
        // and the schema this app always prepares. Failure is fail-STOP — no silent
        // fallback to the local database, which would let a cashier unknowingly sell
        // against stale data.
        // --------------------------------------------------------------------------------
        var lanConfigPath = Path.Combine(
            Path.GetDirectoryName(DatabasePathResolver.GetDatabasePath())!, "lanClient.json");
        if (File.Exists(lanConfigPath))
        {
            try
            {
                // The handshake/pairing/probing awaits run off the dispatcher thread so
                // this synchronous startup can never deadlock against them.
                Task.Run(() => ComposeLanModeAsync(lanConfigPath, connectionString, passwordHasher))
                    .GetAwaiter().GetResult();
            }
            catch (Exception ex)
            {
                MessageBox.Show(
                    "تعذّر الاتصال بخادم الشبكة:\n\n" + ex.Message,
                    "Nova POS - خطأ في الاتصال",
                    MessageBoxButton.OK,
                    MessageBoxImage.Error);
                Shutdown(-1);
                return;
            }

            return;
        }

        UnitOfWork = new UnitOfWork(connectionString);
        AuthService = new AuthService(UnitOfWork.Users, passwordHasher);
        SessionManager = new SessionManager(AuthService);
        // A8: الحارس يُركَّب فوق الجلسة + الإعدادات ويُمرَّر لكل خدمة حساسة —
        // لا مسار إنتاج يبقى بلا حارس (قرار5). حدّ الخصم يُقرأ من الإعدادات
        // (غائب = بلا حدّ = سلوك اليوم بالضبط).
        PermissionGuard = new PermissionGuard(AuthService, UnitOfWork.Settings);
        UserService = new UserService(UnitOfWork.Users, passwordHasher, PermissionGuard);
        // One unit of work, both products and purchases slots — the local mode keeps the
        // exact repositories it always had (the purchase service now reads its
        // repository through the unit of work instead of opening a second context).
        PurchaseService = new PurchaseService(
            UnitOfWork.Purchases, UnitOfWork.Products, PermissionGuard);
        // A7 (محلي فقط): خدمة حساب العميل فوق مستودعها الخاص (معاملات BEGIN IMMEDIATE
        // الخاصة بها) مع مستودع العملاء نفسه من وحدة العمل.
        CustomerAccountService = new CustomerAccountService(
            new CustomerAccountRepository(new DatabaseContext(connectionString)),
            UnitOfWork.Customers,
            PermissionGuard);
        // A9 (محلي فقط): سجل الفواتير والإلغاء والمرتجع — مستودعاه محليان بنمط
        // IUserRepository (بلا Remote: صفحات محلية بقرار · وضع الشبكة يعرض رسالة
        // وظيفية نمط A7 بلا ادعاء حماية خادمية). البوابتان في الخدمتين أول سطر
        // (reports.view للسجل · sale.cancel/sale.return للعمليات — القرار5/6).
        SalesHistoryService = new SalesHistoryService(
            new SalesHistoryRepository(new DatabaseContext(connectionString)),
            PermissionGuard);
        SalesReversalService = new SalesReversalService(
            new SalesReversalRepository(new DatabaseContext(connectionString)),
            PermissionGuard);
        // A14 (محلي فقط): الصندوق والمصروفات والإسناد — مستودعاتها محلية بنمط A9
        // (بلا Remote): في وضع الشبكة تبقى الخدمات null وتعرض الصفحة رسالة وظيفية.
        var cashContext = new DatabaseContext(connectionString);
        ExpenseService = new ExpenseService(new ExpenseRepository(cashContext), PermissionGuard);
        CashRegisterService = new CashRegisterService(new CashTransactionRepository(cashContext), PermissionGuard);
        DayCloseService = new DayCloseService(
            new DayCloseReportRepository(cashContext), new CashTransactionRepository(cashContext), PermissionGuard);
        // D-3: الإسناد بلا حارس — كتابة نظامية بعد نجاح البيع (الفاعل الحالي من الجلسة).
        SaleAttributionService = new SaleAttributionService(new SaleAttributionRepository(cashContext));
        // A15 (محلي فقط): خدمة التقارير الجديدة فوق جداول موجودة — بلا ترحيل
        // جديد ولا تعديل ReportService المحمي ولا أي تغيير LAN.
        StoreReportsService = new StoreReportsService(new StoreReportsRepository(cashContext), PermissionGuard);
        // A16 (محلي فقط): إعدادات المتجر في القاعدة (المفتاحان settings.manage
        // وbackup.manage قائمان في الكتالوج — بلا مفتاح جديد ولا ترحيل ولا LAN).
        StoreSettingsService = new StoreSettingsService(UnitOfWork.Settings, PermissionGuard);
        BackupOperationsService = new BackupOperationsService(
            new BackupEngineAdapter(new BackupService(connectionString)), PermissionGuard);
        // A17 (محلي فقط): لوحة التحكم — منسّق رقيق فوق الخدمات المركّبة أعلاه
        // (A15 الفترة · A14 الخزينة · A9 السجل) + مخزون وحدة العمل المحلية؛
        // بلا معادلات جديدة ولا استعلام كتالوج ولا أي تغيير LAN.
        DashboardService = new DashboardService(
            StoreReportsService, DayCloseService, SalesHistoryService, UnitOfWork.Products, PermissionGuard);
        // A10 (د1/د2): مسوّدات السلة — متجر ملفات الجهاز + بوابة sell في الخدمة،
        // ومصدر المنتجات من وحدة العمل المحلية لفحص الحداثة عند الاستئناف.
        CartDraftService = new CartDraftService(
            new FileCartDraftStore(), UnitOfWork.Products, PermissionGuard);
        // A11: الطباعة والفواتير — نفس التركيب في الوضع المحلي (متجر إعدادات
        // الجهاز + ناقل حقيقي + اسم المتجر من قراءة الإعدادات).
        ComposePrinting();
    }

    /// <summary>
    /// LAN-mode composition (LAN-4): read lanClient.json → pin-verify the server
    /// (handshake: certificate fingerprint + serverId + protocol) → restore or establish
    /// the paired token (DPAPI credential store, scoped to this serverId) → prove the
    /// token live with an authenticated read → build the remote-backed unit of work.
    /// Throws with an explicit Arabic message on any failure; the caller fail-stops.
    /// </summary>
    private static async Task ComposeLanModeAsync(
        string configPath, string connectionString, PasswordHasher passwordHasher)
    {
        var config = JsonSerializer.Deserialize<LanClientConfiguration>(
            File.ReadAllText(configPath), LanConfigJson);
        if (config is null
            || string.IsNullOrWhiteSpace(config.Address)
            || string.IsNullOrWhiteSpace(config.ServerId)
            || string.IsNullOrWhiteSpace(config.Fingerprint))
            throw new InvalidOperationException(
                "ملف lanClient.json غير صالح: الحقول Address و ServerId و Fingerprint مطلوبة.");

        var client = new LanSecurityClient(config.Address, config.ServerId, config.Fingerprint);

        // Pin + serverId + protocol first — nothing else moves before that proof (§9.2).
        await client.ConnectAsync();

        // A stored token that still works is reused; anything else (absent, minted for
        // another server, revoked) establishes a fresh pairing with the one-time code
        // from the server screen — and the new token is proven live before the app runs.
        var credentials = new LanClientCredentialStore();
        client.Token = credentials.Load(config.ServerId);
        if (!await TokenWorksAsync(client))
        {
            if (string.IsNullOrWhiteSpace(config.PairingCode))
                throw new InvalidOperationException(
                    "لا يوجد توكن محفوظ لهذا الخادم ولا يوجد PairingCode في lanClient.json لإجراء الاقتران.");

            var token = await client.PairAsync(config.PairingCode.Trim());
            client.Token = token;
            credentials.Save(config.ServerId, token);

            if (!await TokenWorksAsync(client))
                throw new InvalidOperationException(
                    "التوكن الجديد مرفوض من الخادم؛ أعد إصدار رمز الاقتران ثم أعد التشغيل.");
        }

        var journal = new WriteAheadJournal(connectionString);
        UnitOfWork = new LanUnitOfWork(client, journal, connectionString);
        AuthService = new AuthService(UnitOfWork.Users, passwordHasher);
        SessionManager = new SessionManager(AuthService);
        // A8: نفس تركيبة الحارس في وضع الشبكة — الإعدادات تُقرأ عبر الخادم
        // (غائب = بلا حدّ خصم، سلوك اليوم). لا مسار إنتاج بلا حارس (قرار5).
        PermissionGuard = new PermissionGuard(AuthService, UnitOfWork.Settings);
        UserService = new UserService(UnitOfWork.Users, passwordHasher, PermissionGuard);
        PurchaseService = new PurchaseService(
            UnitOfWork.Purchases, UnitOfWork.Products, PermissionGuard);
        // A10 (د1/د2): نفس التركيب في وضع الشبكة — المسوّدات ملفات جهاز هذا
        // الجهاز وحده (حالة تشغيلية للجهاز)، والاستئناف يبني السلة محليًا بينما
        // الإرسال الأخير يمرّ بـ LanUnitOfWork العادي: لا endpoint جديد ولا لمس LAN-5.
        CartDraftService = new CartDraftService(
            new FileCartDraftStore(), UnitOfWork.Products, PermissionGuard);
        // A11: نفس التركيب في وضع الشبكة — الطابعة على هذا الجهاز وحده، واسم
        // المتجر يمرّ عبر مسار القراءة الخادمي القائم (أي فشل = الاسم الافتراضي).
        ComposePrinting();
    }

    /// <summary>
    /// A11: تركيب الطباعة الموحّد في الوضعين — متجر إعدادات الجهاز + الناقل
    /// الحقيقي (حراري/ورقي حسب الإعداد) + مصدر اسم المتجر للقراءة فقط.
    /// </summary>
    private static void ComposePrinting()
    {
        PrintSettingsStore = new PrintSettingsStore();
        InvoicePrintingService = new InvoicePrintingService(
            new WindowsInvoiceTransport(PrintSettingsStore),
            PrintSettingsStore,
            new AppStoreInfoSource());
    }

    /// <summary>
    /// A11: اسم المتجر من <c>Settings.store_name</c> بقراءة وحدها — محليًا عبر
    /// وحدة العمل المحلية، وشبكة عبر مسار إعدادات الخادم القائم (لا يُنشئ ولا
    /// يعدّل شيئًا). أي فشل يُردّ null فيتولّى الملفّن الاسم الافتراضي.
    /// </summary>
    private sealed class AppStoreInfoSource : IStoreInfoSource
    {
        public async Task<string?> GetStoreNameAsync()
        {
            var settings = UnitOfWork?.Settings;
            if (settings is null)
                return null;

            return await settings.GetAsync("store_name");
        }
    }

    /// <summary>
    /// Live token probe: one authenticated read proves the bearer token works NOW.
    /// A 401 is the only answer that means "pair again"; every other rejection is a
    /// hard stop, surfaced verbatim by the caller.
    /// </summary>
    private static async Task<bool> TokenWorksAsync(LanSecurityClient client)
    {
        try
        {
            await client.GetAsync("/api/v1/settings");
            return true;
        }
        catch (ServerVerificationException ex)
            when (string.Equals(ex.Message, ServerVerificationException.NotAuthenticated, StringComparison.Ordinal))
        {
            return false;
        }
    }

    // lanClient.json is hand-authored (§9.3 manual entry): comments, trailing commas and
    // PascalCase keys are all tolerated; the required fields are validated above.
    private static readonly JsonSerializerOptions LanConfigJson = new(JsonSerializerDefaults.Web)
    {
        PropertyNameCaseInsensitive = true,
        ReadCommentHandling = JsonCommentHandling.Skip,
        AllowTrailingCommas = true
    };
}
