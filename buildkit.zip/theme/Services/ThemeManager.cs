using System.Text.Json;
using System.Windows;
using System.Windows.Media;
using NovaPOS.Data.Database;

namespace NovaPOS.App.Services;

/// <summary>A18: الثيم النشط — فاتح (افتراضي) أو داكن.</summary>
public enum UiTheme
{
    Light,
    Dark,
}

/// <summary>A18: الخط النشط — Cairo افتراضيًا، قابل للتغيير من الإعدادات.</summary>
public enum UiFont
{
    Cairo,
    Tajawal,
    ReadexPro,
    IbmPlexSansArabic,
}

/// <summary>A18: صورة الإعداد في لحظة القراءة/الحفظ.</summary>
public sealed record UiSettings(UiTheme Theme, UiFont Font)
{
    /// <summary>الافتراضي: فاتح + Cairo — ما يُبنى به التطبيق وما يُعاد إليه عند أي عطل.</summary>
    public static UiSettings Default { get; } = new(UiTheme.Light, UiFont.Cairo);
}

/// <summary>
/// A18: متجر إعدادات المظهر على الجهاز (ثيم + خط) — <c>ui-settings.json</c> في مجلد
/// البيانات (<c>%LOCALAPPDATA%\NovaPOS</c> أو بديل <c>NOVAPOS_DATA_DIR</c>)،
/// بالضبط بنمط إعدادات الطباعة A11: ملف جهاز محلي (بلا جدول ولا ترحيل ولا LAN —
/// المظهر حالة جهاز لا بيانات أعمال)، كتابة ذرّية عبر <c>.tmp</c>، والملف التالف
/// يُعزَل بـ <c>.corrupt</c> ويعاد الافتراضي صامتًا.
/// </summary>
public sealed class UiSettingsStore
{
    private const string FileName = "ui-settings.json";

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true,
    };

    private sealed record UiSettingsFile(string Theme, string Font);

    /// <summary>يسلي الإعداد؛ غيابه ⇒ الافتراضي. تلفه ⇒ عزله بـ .corrupt ثم الافتراضي.</summary>
    public UiSettings Load()
    {
        var path = FilePath;
        if (!File.Exists(path))
            return UiSettings.Default;

        try
        {
            var file = JsonSerializer.Deserialize<UiSettingsFile>(File.ReadAllText(path));
            if (file is null)
                return UiSettings.Default;

            return new UiSettings(
                Enum.TryParse<UiTheme>(file.Theme, ignoreCase: true, out var theme) ? theme : UiTheme.Light,
                Enum.TryParse<UiFont>(file.Font, ignoreCase: true, out var font) ? font : UiFont.Cairo);
        }
        catch (Exception ex) when (ex is JsonException or IOException)
        {
            TryIsolateCorrupt(path);
            return UiSettings.Default;
        }
    }

    /// <summary>يحفظ ذرّيًّا: <c>.tmp</c> ثم استبدال الملف (لا حالة نصفية قابلة للقراءة).</summary>
    public void Save(UiSettings settings)
    {
        var path = FilePath;
        Directory.CreateDirectory(Path.GetDirectoryName(path)!);
        var tmp = path + ".tmp";
        File.WriteAllText(tmp, JsonSerializer.Serialize(new UiSettingsFile(settings.Theme.ToString(), settings.Font.ToString()), JsonOptions));
        File.Move(tmp, path, overwrite: true);
    }

    private static string FilePath =>
        Path.Combine(DatabasePathResolver.GetDataDirectory(), FileName);

    private static void TryIsolateCorrupt(string path)
    {
        try
        {
            File.Move(path, path + ".corrupt", overwrite: true);
        }
        catch
        {
            // العزل رفاهية تشخيصية — فشلها لا يغيّر النتيجة (الافتراضي) ولا يوقف أحدًا.
        }
    }
}

/// <summary>
/// A18: مدير الثيم والخط. يُستدعى مرة واحدة في بداية <c>OnStartup</c>
/// (<see cref="Bootstrap"/>) — قبل إنشاء أي نافذة — ثم تتولى صفحة الإعدادات
/// <see cref="SetTheme"/> و <see cref="SetFont"/> (تحفظ وتطبّق مباشرة).
///
/// <para>آلية التبديل: قوامات <c>App.xaml</c> مركّبة بالترتيب (Palette ← Typography
/// ← Controls ← DataGrid) وكل الألوان في القوامات تُستدعى <c>DynamicResource</c>،
/// فاستبدال «شريط الثيم» (أول قوام) بتوأمه الداكن يغيّر التطبيق كله حيًّا —
/// حتى النوافذ المفتوحة. الخط نفسه: موارد <c>AppFontFamily</c> تُستبدل فكل ما
/// يستدعيها (النمط النافذ + كل أنماط التحكم) يتحدث فورًا.</para>
///
/// <para>مبدأ المظهر: <b>لا يوقف أحدًا</b>. أي فشل (ملف تالف، خط مفقود…) يعود
/// بالافتراضي (فاتح + Cairo) دون انقلاع — المظهر تجميلي لا يحمل بيانات.</para>
/// </summary>
public static class ThemeManager
{
    /// <summary>مراجع الخطوط المضمّنة (Resource داخل التجمّع — صفر إنترنت وقت التشغيل).</summary>
    private static readonly IReadOnlyDictionary<UiFont, string> FontPackUris =
        new Dictionary<UiFont, string>
        {
            [UiFont.Cairo] = "pack://application:,,,/NovaPOS.App;component/Fonts/#Cairo",
            [UiFont.Tajawal] = "pack://application:,,,/NovaPOS.App;component/Fonts/#Tajawal",
            [UiFont.ReadexPro] = "pack://application:,,,/NovaPOS.App;component/Fonts/#Readex Pro",
            [UiFont.IbmPlexSansArabic] = "pack://application:,,,/NovaPOS.App;component/Fonts/#IBM Plex Sans Arabic",
        };

    private static Application? _app;
    private static UiSettings _current = UiSettings.Default;
    private static UiSettingsStore? _store;

    /// <summary>الإعداد الحالي النشط (للإظهار في صفحة الإعدادات).</summary>
    public static UiSettings Current
    {
        get { lock (Sync) return _current; }
    }

    private static readonly object Sync = new();

    /// <summary>
    /// مرة واحدة في بداية OnStartup، قبل أي نافذة. يقرأ إعداد الجهاز ويطبقها؛
    /// أي فشل ⇒ الافتراضي (المظهر لا يوقف أحدًا).
    /// </summary>
    public static void Bootstrap(Application app)
    {
        lock (Sync)
        {
            _app = app;
            _store = new UiSettingsStore();
        }

        UiSettings settings;
        try
        {
            settings = _store.Load();
        }
        catch
        {
            settings = UiSettings.Default;
        }

        Apply(app, settings);
    }

    /// <summary>يبدّل الثيم (يحفظ + يبدل القوام) — استدعاء صفحة الإعدادات.</summary>
    public static void SetTheme(UiTheme theme)
    {
        lock (Sync)
        {
            if (_app is null)
                return;
            _current = _current with { Theme = theme };
            TryPersist();
            SwapPalette(_app, theme);
        }
    }

    /// <summary>يبدّل الخط (يحفظ + يستبدل مورد AppFontFamily) — استدعاء صفحة الإعدادات.</summary>
    public static void SetFont(UiFont font)
    {
        lock (Sync)
        {
            if (_app is null)
                return;
            _current = _current with { Font = font };
            TryPersist();
            SetFontFamily(_app, font);
        }
    }

    private static void Apply(Application app, UiSettings settings)
    {
        lock (Sync)
        {
            _current = settings;
        }
        try
        {
            SwapPalette(app, settings.Theme);
            SetFontFamily(app, settings.Font);
        }
        catch
        {
            // ثيم غير مكتمل (ملف قوام مفقود مثلًا) ⇒ نتراجع للافتراضي كاملًا.
            SwapPalette(app, UiTheme.Light);
            SetFontFamily(app, UiFont.Cairo);
            lock (Sync)
            {
                _current = UiSettings.Default;
            }
        }
    }

    private static void TryPersist()
    {
        try
        {
            _store?.Save(_current);
        }
        catch
        {
            // حفظ المظهر فشل (مسار مقلقة مثلًا) — تبقى الجلسة على الاختيار الجديد
            // دون إزعاج؛ المحاولة القادمة تعيد القراءة من الملف السابق.
        }
    }

    /// <summary>يستبدل «شريط الثيم» (أول قوام) بمضمون الثيم المختار — الترقيم محفوظ.</summary>
    private static void SwapPalette(Application app, UiTheme theme)
    {
        var source = theme == UiTheme.Dark
            ? "Styles/Theme/Palette.Dark.xaml"
            : "Styles/Theme/Palette.Light.xaml";

        var dictionaries = app.Resources.MergedDictionaries;
        for (var i = 0; i < dictionaries.Count; i++)
        {
            var existing = dictionaries[i].Source?.OriginalString ?? string.Empty;
            if (existing.EndsWith("Palette.Light.xaml", StringComparison.Ordinal)
                || existing.EndsWith("Palette.Dark.xaml", StringComparison.Ordinal))
            {
                dictionaries[i] = new ResourceDictionary { Source = new Uri(source, UriKind.Relative) };
                return;
            }
        }

        // لا شريط ثيم (قوامات معدّلة يدويًّا مثلًا) ⇒ نضيفه أولًا (شرط الترتيب).
        dictionaries.Insert(0, new ResourceDictionary { Source = new Uri(source, UriKind.Relative) });
    }

    /// <summary>
    /// يستبدل موردي الخط: <c>AppFontFamily</c> (الثيم الجديد) و <c>AppFont</c>
    /// (اسم التوافق الذي تكتبه الـViews القديمة) — كل DynamicResource المربوطة
    /// بهما تتحدّث حيًّا (و StaticResource يلتقط الخط عند إعادة التشغيل).
    /// </summary>
    private static void SetFontFamily(Application app, UiFont font)
    {
        var family = new FontFamily(FontPackUris[font]);
        app.Resources["AppFontFamily"] = family;
        app.Resources["AppFont"] = family;
    }
}
