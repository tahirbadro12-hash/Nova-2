# A18 — وثيقة نظام الثيم (Apple Style)

تاريخ: 2026-11-01 · الحالة: جاهز للبناء على ويندوز · النطاق: `NovaPOS.App` فقط

## 1. ما الذي أضيف؟

| الملف | الدور |
|---|---|
| `Styles/Theme/Palette.Light.xaml` | القوامون (Tokens) الفاتح — «شريط الثيم» الافتراضي |
| `Styles/Theme/Palette.Dark.xaml` | القوامون الداكن — متناظر بنفس المفاتيح والترتيب |
| `Styles/Typography.xaml` | `AppFontFamily` (يُبدل وقت التشغيل) + نمط النافذة + أنماط النص المسمّاة |
| `Styles/Controls.xaml` | كل أنماط التحكم: أزرار · حقول · ComboBox · CheckBox/Radio/Switch · شريط تمرير · ToolTip · قائمة سياق · ProgressBar · Tabs · ListBox · بطاقات · شرائح |
| `Styles/DataGrid.xaml` | DataGrid بنمط Apple (ترويسة/صفوف/خلايا/تحديد) |
| `Services/ThemeManager.cs` | قارئ/حافظ إعداد الجهاز + مبدّل الثيم والخط (حيّ) |
| `Fonts/*.ttf` (11) | Cairo (4 أوزان) · Tajawal (3) · Readex Pro (4) — من google/fonts (OFL) |
| `App.xaml` (عدّل) | أول قوام صار `Styles/Theme/Palette.Light.xaml` (الترتيب باقي) |
| `App.xaml.cs` (عدّل) | `ThemeManager.Bootstrap(this)` أول سطر في `OnStartup` |
| `NovaPOS.App.csproj` (عدّل) | خطوط جديدة كـ Resource (IBM Plex باقٍ) |

## 2. قواعد النظام (لا تُكسر)

1. **شرط الترتيب** في `App.xaml`: Palette ← Typography ← Controls ← DataGrid.
   «شريط الثيم» هو أول قوام دائمًا — `ThemeManager` يتعرف عليه باسمه
   (`Palette.Light/Dark.xaml`) ويستبدله.
2. **التناظر**: كل مفتاح في `Palette.Light` له توأم بنفس الاسم في
   `Palette.Dark` والعكس. لا لون في ثيم بلا لون في الآخر.
3. **كل الألوان عبر `DynamicResource`** — الثابتات الشكلية (الزوايا) عبر
   `StaticResource`. من خالف القاعدة يجمّد نفسه على ثيم واحد.
4. **لا نمط ضمني لـ `TextBlock`** في أي قوام (ينسلّ إلى القوالب الداخلية
   ويكسرها) — النصوص المسمّاة فقط (`PageTitle`…)، والنص العادي يرث من نمط
   النافذة (خط/حجم/لون).
5. **الإعدادات جهازية** (`ui-settings.json` في مجلد البيانات) بنمط
   `print-settings.json` (A11): بلا جدول، بلا ترحيل، بلا LAN — المظهر حالة
   جهاز. الكتابة ذرّية (`.tmp`) والتلف يعزل (`.corrupt`) ويعود الافتراضي.
6. **المظهر لا يوقف أحدًا**: أي فشل في `ThemeManager` ⇒ فاتح + Cairo دون انقلاع.

## 3. مفاتيح الاستخدام من الصفحات (XAML)

```xml
<!-- زر إجراء أساسي / ثانوي (الضمني) / خطر -->
<Button Style="{StaticResource PrimaryButton}">حفظ</Button>
<Button>إلغاء</Button>
<Button Style="{StaticResource DangerButton}">حذف</Button>
<Button Style="{StaticResource IconButton}">⚙</Button>
<Button Style="{StaticResource LinkButton}">عرض الكل</Button>

<!-- حقل مع Placeholder (ضع التلميح في Tag) -->
<TextBox Tag="اسم المنتج"/>
<PasswordBox Tag="كلمة المرور"/>
<ComboBox ItemsSource="..."/>

<!-- مفتاح تبديل iOS -->
<ToggleButton Style="{StaticResource SwitchStyle}"/>

<!-- بطاقة + رقم إحصائي -->
<Border Style="{StaticResource Card}">
    <StackPanel>
        <TextBlock Style="{StaticResource StatValue}" Text="12,450.00"/>
        <TextBlock Style="{StaticResource StatLabel}" Text="مبيعات اليوم"/>
    </StackPanel>
</Border>

<!-- شريحة حالة -->
<Border Style="{StaticResource ChipSuccess}"><TextBlock Text="متوفر"/></Border>
<!-- تنويعات: Chip (افتراضي) · ChipSuccess · ChipWarning · ChipDanger · ChipAccent -->

<!-- عناوين -->
<TextBlock Style="{StaticResource PageTitle}" Text="المبيعات"/>
<TextBlock Style="{StaticResource SectionTitle}" Text="ملخص الفترة"/>
<TextBlock Style="{StaticResource FieldLabel}" Text="العميل"/>
<TextBlock Style="{StaticResource HintText}" Text="اختياري"/>

<!-- أرقام ملوّنة: StatValueSuccess · StatValueWarning · StatValueDanger -->
```

## 4. ربط صفحة الإعدادات (جاهز للصق — `SettingsPage` وصل)

القسم يُصق في `SettingsPage.xaml` بعد قسم «إعدادات الطباعة» (قبل قسم
«إعدادات المتجر»):

```xml
<!-- A18: المظهر — ثيم + خط (إعداد جهاز محلي بلا قاعدة بيانات) -->
<Border Margin="0,12,0,0" Padding="14" BorderBrush="{StaticResource BorderBrush}"
        BorderThickness="1" CornerRadius="{StaticResource RadiusCard}">
    <StackPanel>
        <TextBlock Text="🎨 المظهر" Style="{StaticResource SectionTitleText}"/>

        <TextBlock Text="الثيم:" Style="{StaticResource LabelText}" Margin="0,0,0,4"/>
        <ComboBox x:Name="ThemeBox" Height="{StaticResource FieldHeight}"
                  SelectionChanged="ThemeBox_OnSelectionChanged"
                  ToolTip="يُطبّق فورًا على كل النوافذ المفتوحة ويُحفظ على هذا الجهاز">
            <ComboBoxItem Content="فاتح (الافتراضي)"/>
            <ComboBoxItem Content="داكن"/>
        </ComboBox>

        <TextBlock Text="خط الواجهة:" Style="{StaticResource LabelText}" Margin="0,10,0,4"/>
        <ComboBox x:Name="FontBox" Height="{StaticResource FieldHeight}"
                  SelectionChanged="FontBox_OnSelectionChanged"
                  ToolTip="خطوط مضمّنة في التطبيق — صفر إنترنت وقت التشغيل">
            <ComboBoxItem Content="Cairo (الافتراضي)"/>
            <ComboBoxItem Content="Tajawal"/>
            <ComboBoxItem Content="Readex Pro"/>
            <ComboBoxItem Content="IBM Plex Sans Arabic"/>
        </ComboBox>

        <TextBlock Style="{StaticResource CaptionText}" Margin="0,8,0,0"
                   Text="المظهر إعداد جهاز — يُحفظ في ملف محلي ولا يُرسل عبر الشبكة ولا يمسّ قاعدة البيانات."/>
    </StackPanel>
</Border>
```

وكود الـcode-behind (مُفحوص على `SettingsPage.xaml.cs` الفعلي — عندها
`InitializeComponent()` و`LoadPrintSettings()` موجودان مسبقًا):

```csharp
// 1) using جديد أعلى الملف:
using NovaPOS.App.Services;

// 2) داخل مُنشئ SettingsPage الموجود — أضف سطرًا واحدًا بعد InitializeComponent();
Loaded += OnUiAppearanceLoaded;

// 3) الأعضاء الثلاثة + الحقل، في أي مكان داخل الصنف:
private bool _suppressAppearanceEvents;

private void OnUiAppearanceLoaded(object sender, RoutedEventArgs e)
{
    var cur = ThemeManager.Current;
    _suppressAppearanceEvents = true;
    ThemeBox.SelectedIndex = cur.Theme == UiTheme.Dark ? 1 : 0;
    FontBox.SelectedIndex = (int)cur.Font;   // ترتيب العناصر = ترتيب enum UiFont
    _suppressAppearanceEvents = false;
}

private void ThemeBox_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
{
    if (_suppressAppearanceEvents || ThemeBox.SelectedIndex < 0) return;
    ThemeManager.SetTheme(ThemeBox.SelectedIndex == 1 ? UiTheme.Dark : UiTheme.Light);
}

private void FontBox_OnSelectionChanged(object sender, SelectionChangedEventArgs e)
{
    if (_suppressAppearanceEvents || FontBox.SelectedIndex < 0) return;
    ThemeManager.SetFont((UiFont)FontBox.SelectedIndex);
}
```

ملاحظة: إن كان في الصفحة `InitializeComponent()` و`Loaded` موجودان مسبقًا
(للطباعة) فلا تضغطهما — أضف اشتراك `Loaded` وبقية الأعضاء فقط.
التبديل حيّ: كل `DynamicResource` يتحدّث فورًا في كل النوافذ المفتوحة؛
الخطوط التي استُدعيت `StaticResource` (مثل بعض خصائص `FontFamily` في الـViews)
تلتقط الخط الجديد عند إعادة التشغيل.

## 5. ترقية الخطوط مستقبلًا

الخطوط صيغت من متغيرات `google/fonts`:
`fontTools.varLib.instancer <variable.ttf> wght=400..700 -o Statics` ثم تصحيح
جدول الأسماء (family/subfamily). كل خط: 400/500/600/700 (Tajawal بلا 600).
الرخصة OFL 1.1 للجميع — `Fonts/OFL.txt` المرفق يغطيهم.

## 6. توافق أسماء الثيم القديم (مكتمل — الـViews وصلت وفُحصت)

وصلت الـViews الكاملة (25 ملف XAML) وفُحص كل مرجع `StaticResource`/
`DynamicResource` فيها: **صفر مفاتيح ناقصة**. كل اسم قديم مكتوب في
الـViews موجود الآن في القوامات الجديدة بالقيمة الجديدة المقابلة:

| المفتاح القديم | في الثيم الجديد | ملاحظة |
|---|---|---|
| `PrimaryBrush` | «حبر» الهوية: فاتح `#1D1D1F` / داكن `#141416` | خلفية الشريط الجانبي ونافذة الدخول — داكن دائمًا في القمريّتين (نصه الأبيض `TextOnDarkBrush`) |
| `TextMutedBrush` | `TextTertiaryBrush` | |
| `TextOnDarkBrush` / `TextOnDarkMutedBrush` | أبيض / رمادي على الحبر | الشريط الجانبي |
| `ErrorTextBrush` / `SuccessTextBrush` | `LabelDangerBrush` / `LabelSuccessBrush` | |
| `RowAltBrush` | سطر متناوب (فاتح `#FBFBFD` / داكن `#28282A`) | |
| `PageBackgroundBrush` | `AppBackgroundBrush` | |
| `FontSize{Display,PageTitle,Total,Section,CardTitle,Body,Small,Caption,Tiny}` | نفس القيم 28/24/20/18/16/14/13/12/11 | |
| `FieldHeight`/`ButtonHeight`/`ButtonHeightCompact`/`ButtonHeightLarge` | 36/36/30/44 | |
| `Spacing{Xs,Sm,Md,Lg,Xl}` | 4/8/12/16/20 | |
| `RadiusControl` / `RadiusCard` | `8` / `12` | كان 4/4 — استدارات Apple الجديدة |
| `AppFont` | مفتاح خط حيّ (بجانب `AppFontFamily`) | `ThemeManager` يُحدّث الاثنين معًا |
| `PageTitleText`/`SectionTitleText`/`CardTitleText`/`LabelText`/`CaptionText` | أنماط `Typography.xaml` (قيم قديمة، ألوان جديدة) | |
| `StatusText` / `StatusSuccessText` | أنماط `Typography.xaml` (13 SemiBold، خطأ أحمر / نجاح أخضر) | |
| `AccentButton` / `SuccessButton` | `Controls.xaml` — بنفس مظهر `PrimaryButton`/نمط النجاح الجديد | `DangerButton` موجود أصلًا |
| `LoadingBar` | ProgressBar غير محدد الارتفاع 4px بلون `AccentBrush` | |
| `GridRow` / `GridColumnHeader` / `GridCell` | مبنية على الأنماط الضمنية الجديدة (نفس المظهر) | |
| نمط `Label` الضمني | أُضيف (كان موجودًا في الثيم القديم ويستخدمه 12 صفحة) | |

الأسماء الجديدة (الموصى بها مستقبلًا) بقيت كما هي: `AccentBrush`,
`AppBackgroundBrush`, `ControlCornerRadius`, `Card`, `PageTitle`, …
والملف القديم `Styles/Palette.xaml` يُحذف من مشروع البناء (يحل محله
`Styles/Theme/Palette.Light.xaml`) — وكذلك `Typography/Controls/DataGrid.xaml`
القديمة تُستبدل بنسخها الجديدة. `NullToVis` معرّف محليًّا داخل
`SalesHistoryPage.xaml` (لا علاقة له بالثيم).

## 7. ملاحظات أخرى قبل أول بناء

- `NovaPOS - Copie.sln` و`NovaPOS.App_wxblfmzbs_wpftmp.csproj` في جذر الحزمة
  ملفا بناء مؤقتان — لا يُعمَل عليهما؛ الحزمة الفعلية `NovaPOS.sln`.
- إن ظهر خطأ بناء مع ذلك بنمط «resource named X not found»: أرسل النص
  السطر → المفتاح يُضاف فورًا (القوامات مكتملة حاليًّا لكل ما في
  `xaml.zip`).
